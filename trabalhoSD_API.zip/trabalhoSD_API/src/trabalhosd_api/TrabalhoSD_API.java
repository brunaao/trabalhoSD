/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhosd_api;

import java.util.List;
import java.util.Vector;

/**
 *
 * @author br
 */
public class TrabalhoSD_API {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Servidor serv = new Servidor();
        Byte[] l = new Byte[]{0x51, 0x52}; 
        Servidor.set(1L, Long.MIN_VALUE, l);
        System.out.println(Servidor.dadosBd.toString());
    }
    
}
